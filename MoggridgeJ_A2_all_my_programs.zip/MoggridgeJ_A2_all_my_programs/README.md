# sklearn_example_pipelines

Support vector machines and logistic regression classifers. Runs on cancer data, abalone, and diabetes datasets by executing the script `run_all_pipelines.sh`; tools/ and scripts/ folders need to be in the same directory as this shell script for the hard-coded filepaths to work.
