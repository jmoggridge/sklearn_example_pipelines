#!/bin/sh

rm -rf *folded-[0-9][0-9]
rm -rf *train-vs-test

